
import java.util.Date;
import java.util.TimerTask;

public class Timers extends TimerTask {

    @SuppressWarnings("deprecation")
	@Override
    public void run() {
        System.out.println(new Date().getSeconds());
    }

    public static void main(String args[]){
        Timers timer = new Timers();
        System.out.println("TimerTask started");
        for(int i=0;i<10;i++) {
        try {
        	timer.run();
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        }
        System.out.println("TimerTask Stopped");
        timer.cancel();
    }

}
