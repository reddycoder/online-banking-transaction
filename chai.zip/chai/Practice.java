class Parent{
	
	  public void finalize() {
			System.out.println("Finalize Method Called");
		}
}

public class Practice  {
	
	public static void main(String[] args) {
		Parent p = new Parent();
		p = new Parent();
		p = new Parent();
		Runtime.getRuntime().gc();
	}
}
