import java.util.HashMap;
import java.util.Scanner;

public class HashMapProgram {

	public static void main(String[] args) {
		HashMap<String,String> hs = new HashMap<>();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Number of details of Telephone book you have to enter");
		int size = Integer.parseInt(sc.nextLine());
		System.out.println("Enter details of Telephone book(i.e name and phone number) separated by ,(coma)");
		for(int i=0;i<size;i++) {
			String name = sc.nextLine();
			String[] value = name.split(",");
			hs.put(value[0],value[1]);
		}
		System.out.println("Enter details of Telephone book(i.e name) to search");
		String name = sc.nextLine();
			if(hs.containsKey(name)) {
				System.out.println(name+" Phone number is "+hs.get(name));
			}
			else
				System.out.println(name+" is not present in Telephone directory");

			sc.close();
	}

}
