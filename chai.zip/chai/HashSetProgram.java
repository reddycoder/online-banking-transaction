import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;

class Employee {
	private String name;
	private Integer contact;
	private String branch;
	
	public Employee() {
		super();
	}
	public Employee(String name, Integer contact, String branch) {
		super();
		this.name = name;
		this.contact = contact;
		this.branch = branch;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getContact() {
		return contact;
	}
	public void setContact(Integer contact) {
		this.contact = contact;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	@Override
	public String toString() {
		return  name +" " + contact + " " + branch;
	}
}
public class HashSetProgram {

	public static void main(String[] args) {
		HashSet<Employee> hs = new HashSet<>();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Number of Employees you have to enter");
		int size = Integer.parseInt(sc.nextLine());
		System.out.println("Enter details of Employee(i.e name and phone number and Address) separated by ,(coma)");
		for(int i=0;i<size;i++) {
			String name = sc.nextLine();
			String[] value = name.split(",");
			Integer number = Integer.parseInt(value[1]);
			Employee e = new Employee(value[0],number,value[2]);
			hs.add(e);
		}
		System.out.println("Employee Details\n");
		System.out.println("Name\tPhone\tAddress\n");
		Iterator<Employee> it = hs.iterator();
		while(it.hasNext()) {
			System.out.println(it.next().toString());
		}
		sc.close();	
	}

}
